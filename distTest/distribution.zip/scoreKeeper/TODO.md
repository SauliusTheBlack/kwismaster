- width of input fields
- some modicum of styling


- probably going to need to store scores as a js file, so that it can be read by the reveal parser.